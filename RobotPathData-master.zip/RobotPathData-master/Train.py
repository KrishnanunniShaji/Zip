import numpy as np


import segmentation_models_pytorch as smp
import torch.optim as optim
import torch.nn as nn

import torch
from torch.utils.data import Dataset, Subset
from torch.utils.data import DataLoader
import torchvision.transforms as transforms
import os
from wzk import sql2, trajectory
from torchmetrics import JaccardIndex
import matplotlib.pyplot as plt
# import torchvision.models.segmentation as models
file = "SingleSphere02.db"
os.environ['CUDA_LAUNCH_BLOCKING'] = '1'
if torch.cuda.is_available():
    # CUDA is available
    print("CUDA is available")
else:
    # CUDA is not available
    print("CUDA is not available")

#############
n_voxels = 64
voxel_size = 10 / 64     # in m
extent = [0, 10, 0, 10]  # in m
n_waypoints = 22  # start + 20 inner points + end
n_dim = 2
n_paths_per_world = 1000
n_worlds = 5000

# sql2.summary(file)

worlds = sql2.get_values_sql(file=file, table="worlds", values_only=False)
obstacle_images = sql2.compressed2img(img_cmp=worlds.img_cmp.values, shape=(n_voxels, n_voxels), dtype=bool)


##########

device=torch.device('cuda')

#print(input.shape,output_images.shape)
class RobotPath(Dataset):
    def __init__(self):
        super(RobotPath, self).__init__()
    def __getitem__(self, index):
        paths = sql2.get_values_sql(file=file, table="paths", rows=index, values_only=False)
        path_images = sql2.compressed2img(img_cmp=paths.pathimg_cmp.values, shape=(n_voxels, n_voxels), dtype=bool)
        start_images = sql2.compressed2img(img_cmp=paths.startimg_cmp.values, shape=(n_voxels, n_voxels), dtype=bool)
        end_images = sql2.compressed2img(img_cmp=paths.endimg_cmp.values, shape=(n_voxels, n_voxels), dtype=bool)
        # batch_i_world = paths.world_i32.values
        # print(batch_i_world)
        # batch_i_world=batch_i_world//1000

        batch_i_world=np.array([index//1000])
        # print(batch_i_world)
        obstacle_images_batch = obstacle_images[batch_i_world]
        input_images2 = np.concatenate([np.logical_or(start_images[..., np.newaxis],
                                                      end_images[..., np.newaxis]),obstacle_images_batch[..., np.newaxis]], axis=-1)
        output_images = path_images[..., np.newaxis]


        input_images2=torch.from_numpy(input_images2).float()
        output_images=torch.from_numpy(output_images).float()
        # print(input_images2.shape,output_images.shape)
        input_images2 = input_images2.permute(0, 3, 1, 2)
        output_images = output_images.permute(0, 3, 1, 2)
        input_images2=input_images2.squeeze(0)
        output_images=output_images.squeeze(0)
        return input_images2, output_images


Train=RobotPath()

selected_indices_train = list(range(0, 79999 + 1))
TrainDataset = Subset(Train, selected_indices_train)
selected_indices_test = list(range(80000, 99999 + 1))
TestDataset=Subset(Train, selected_indices_test)
TrainDataloader = DataLoader(TrainDataset, batch_size=32, shuffle=True)
TestDataLoader=DataLoader(TestDataset, batch_size=32, shuffle=True)
selected_indices_val = list(range(80000, 89999 + 1))
ValDataset=Subset(Train, selected_indices_val)
ValDataLoader=DataLoader(ValDataset, batch_size=32, shuffle=True)


Model= smp.Unet(
    encoder_name="resnet34",
    encoder_weights="imagenet",
    in_channels=2,
    classes=1)
# checkpoint=torch.load('Adam.pth')
# Model.load_state_dict(checkpoint['model_state'])
total_params = sum(p.numel() for p in Model.parameters() if p.requires_grad)
print("Total Parameters:", total_params)


class DiceLoss(nn.Module):
    def __init__(self):
        super(DiceLoss, self).__init__()
        self.output=nn.Sigmoid()
    def forward(self, predicted, target):
        predicted=self.output(predicted)

        intersection = torch.sum(predicted * target)
        union = torch.sum(predicted)+torch.sum(target)
        dice_coefficient = (2 * intersection) / (union + 1e-8)
        dice_loss = 1 - dice_coefficient
        return dice_loss

Model=Model.to(device)
Criterion=nn.BCEWithLogitsLoss()
# Criterion=DiceLoss()
#optimizer = optim.SGD(Model.parameters(), lr=0.01)
optimizer = optim.Adam(Model.parameters(), lr=0.01)
# #
checkpoint = {
    "model_state":Model.state_dict(),
    "optim_state":optimizer.state_dict()
}

for i in range(50):
    Model.train()
    print("Training Started")
    for data, label in TrainDataloader:

        data=data.to(device)
        label = label.to(device)
        #print(label)

        obstacle = data[:, 1, :, :].clone()
        obstacle=obstacle.unsqueeze(1)

        Output=Model(data)

        # print(obstacle.shape, Output.shape)
        # Loss1=torch.sum(obstacle * Output)
        # Loss1=torch.abs(Loss1/32)
        # print(Loss1)

        label=label.to(device)
        #Loss=Criterion(Output.view(Output.size(0),-1),label.view(label.size(0),-1))

        Loss = Criterion(Output, label)
        Output1=torch.sigmoid(Output)

        Loss1 = torch.sum(obstacle * Output1) / torch.sum(Output1)
        # print(Loss1)

        optimizer.zero_grad()
        LossCombined=Loss+5*Loss1
        LossCombined.backward()
        optimizer.step()
        print(f"Batch Loss:{LossCombined}")

    if (i + 1) % 5 == 0:
        torch.save(checkpoint, f"Checkpoint_{i}.pth")
        #############################################################################################
        Epochs=[]
        Accuracy=[]
        Model.eval()
        with torch.no_grad():
            SumIou = 0
            n_samples = 0
            print("Validation Begins")
            for j, (data, label) in enumerate(ValDataLoader):
                Model = Model.to(device)
                data = data.to(device)
                label = label.to(device)
                data_transformed = Model(data)
                data_transformed = torch.sigmoid(data_transformed)

                data_transformed = (data_transformed > 0.5).float()

                extent = [0, 10, 0, 10]
                fig, ax = plt.subplots()

                startend = data[0, 0, :, :].clone().cpu().numpy()
                obstacle = data[0, 1, :, :].clone().cpu().numpy()
                # ax.imshow(obstacle.T, origin='lower', extent=extent, cmap='binary')
                # ax.imshow(startend.T, origin='lower', extent=extent, cmap='Greens', alpha=0.4)
                # ax.imshow(data_transformed[0,0,...].cpu().numpy().T, origin='lower', extent=extent, cmap='Blues', alpha=0.2)
                # plt.show()

                iou_metric = JaccardIndex(num_classes=1, task='binary')
                iou_metric = iou_metric.to(device)
                iou = iou_metric(data_transformed, label)

                cumulative_iou = iou.item()

                SumIou += cumulative_iou * label.size(0)
                n_samples += label.size(0)
            Fin = SumIou/n_samples
            print(f"Validation Accuracy after Epoch {i}=",Fin)
            Accuracy.append(Fin)
            Epochs.append(i)


  #######################################################################################################

    print(f"Epoch {i} completed")


plt.plot(Epochs, Accuracy, marker='o', linestyle='-')
plt.title('Accuracy vs. Epochs')
plt.xlabel('Epochs')
plt.ylabel('Accuracy')
plt.grid(True)
plt.savefig('accuracy_vs_epochs.jpg')


print("Training ended and final model saved")
torch.save(checkpoint,"Final.pth")


Model.eval()
with torch.no_grad():
    SumIou=0
    n_samples=0
    print("Testing Begins")
    for i, (data, label) in enumerate(TestDataLoader):
        Model=Model.to(device)
        data=data.to(device)
        label=label.to(device)
        data_transformed=Model(data)
        data_transformed=torch.sigmoid(data_transformed)

        data_transformed=(data_transformed>0.5).float()


        extent = [0, 10, 0, 10]
        fig, ax = plt.subplots()

        startend=data[0,0,:,:].clone().cpu().numpy()
        obstacle=data[0, 1, :, :].clone().cpu().numpy()
        # ax.imshow(obstacle.T, origin='lower', extent=extent, cmap='binary')
        # ax.imshow(startend.T, origin='lower', extent=extent, cmap='Greens', alpha=0.4)
        # ax.imshow(data_transformed[0,0,...].cpu().numpy().T, origin='lower', extent=extent, cmap='Blues', alpha=0.2)
        # plt.show()



        iou_metric=JaccardIndex(num_classes=1,task='binary')
        iou_metric=iou_metric.to(device)
        iou=iou_metric(data_transformed,label)

        cumulative_iou=iou.item()


        SumIou+=cumulative_iou*label.size(0)
        n_samples+=label.size(0)


        # print(f"Average IoU of batch {i+1}={cumulative_iou}")

    print(f"Final Average IoU={SumIou/n_samples}")














