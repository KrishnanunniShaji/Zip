from unittest import TestCase

# from wzk.mpl2.figure import new_fig


class Test(TestCase):
    def test_limits2extent(self):
        pass

    def test_align(self):
        pass
