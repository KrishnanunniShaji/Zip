# RobotPathData

Collection of paths for different robots and environments.

Until a better solution with GitHub is found, the data itself lies on GoogleDrive.


---
# Dependencies
* [wzk](https://github.com/scleronomic/WerkZeugKasten):   
`pip install git+ssh://git@github.com/scleronomic/wzk.git@stable-adlr`
