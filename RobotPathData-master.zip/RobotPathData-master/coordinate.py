import numpy as np
from main import input_images2, q,input_images3
import torch.optim as optim
import torch.nn as nn
import torchvision.models as models
import torch
from torch.utils.data import Dataset
from torch.utils.data import DataLoader
import torchvision.transforms as transforms
import os
import torch.optim.lr_scheduler as lr_scheduler
import matplotlib.pyplot as plt

os.environ['CUDA_LAUNCH_BLOCKING'] = '1'
if torch.cuda.is_available():
    print("CUDA is available")
else:
    print("CUDA is not available")
input =torch.from_numpy(input_images3).float()
output_path=torch.from_numpy(q).float()
device=torch.device('cuda')



class RobotPath(Dataset):
    def __init__(self,input_test, output_test, transform):
        super(RobotPath, self).__init__()
        self.input=input_test
        self.output=output_test
        self.transform=transform
    def __len__(self):
        return len(self.input)

    def __getitem__(self, index):

        return self.transform(self.input[index]), self.output[index]

resize_transform = transforms.Resize((64, 64))
input_train = input[:800, ...].clone().permute(0, 3, 1, 2)
input_test = input[800:1000, ...].clone().permute(0, 3, 1, 2)
output_train=output_path[:800, ...].clone()
output_test=output_path[800:1000, ...].clone()

TrainDataset=RobotPath(input_train,output_train,resize_transform)
TestDataset=RobotPath(input_test,output_test,resize_transform)

print(TrainDataset[0][1].shape)

TrainDataloader=DataLoader(TrainDataset,batch_size=32,shuffle=True)
TestDataLoader=DataLoader(TestDataset,batch_size=32, shuffle=True)

Model = models.resnet50(pretrained=True)
#Model.conv1=nn.Conv2d(3, 64, kernel_size=7, stride=2, padding=3, bias=True)
Model.avgpool =nn.AdaptiveAvgPool2d(1)

input_features=Model.fc.in_features
Model.fc = nn.Sequential(
    nn.Linear(input_features, 512),
    nn.ReLU(),
    nn.Dropout(0.2,inplace=False),
    nn.Linear(512, 44)
)
Model=Model.to(device)
print(Model)
total_params = sum(p.numel() for p in Model.parameters() if p.requires_grad)
print("Total Parameters:", total_params)

def euclidean_distance_loss(predicted_coords, ground_truth_coords):
    distance = torch.sqrt(torch.sum((predicted_coords - ground_truth_coords) ** 2, dim=2))
    #print(distance.shape)
    loss = torch.mean(distance)
    return loss
# Criterion=euclidean_distance_loss
Criterion=nn.MSELoss()
optimizer = optim.SGD(Model.parameters(), lr=0.01,momentum=0.9)
# scheduler = lr_scheduler.StepLR(optimizer, step_size=40, gamma=0.1)



for i in range(50):
    for data, label in TrainDataloader:

        data=data.to(device)
        label = label.to(device)
        # print(label.size)
        Output=Model(data)
        # print(Output.size())

        Output=Output.view(-1, 22, 2)
        Output[:, [0, -1], :] = label[:, [0, -1], :]
        Output[:, [0, -1], :] = Output[:, [0, -1], :].detach()




        print(rounded_tensor[0])
        print(rounded_tensor[:,:,1].shape)


        # dat=dat.float()
        # print(dat.shape)
        break



        #print(Output.shape, label.shape)
        #label=label.to(device)

        Loss = Criterion(Output, label)

        #Loss = Criterion(Output, label)
        optimizer.zero_grad()
        Loss.backward()
        optimizer.step()
        # scheduler.step()
        print(f"Batch Loss:{Loss}")

    print(f"Epoch {i} completed")

checkpoint = {
     "Epoch":i,
     "model_state":Model.state_dict(),
     "optim_state":optimizer.state_dict()
 }

print("Training ended and model saved")
# torch.save(checkpoint,"Ppt.pth")
# checkpoint=torch.load('Ppt.pth')
# Model.load_state_dict(checkpoint['model_state'])
Model.to(device)
print("Testing begins")
Model.eval()
with torch.no_grad():
    Overall_loss=0
    Total_samples=0
    for i,(data, label) in enumerate(TestDataLoader):
        break
        data=data.to(device)
        label = label.to(device)
        #print(label)
        Output=Model(data)

        n_samples = label.size(0)
        Output=Output.view(-1, 22, 2)
        Output[:, [0, -1], :]=label[:, [0, -1], :]
        Output[:,[0,-1],:]=Output[:,[0,-1],:].detach()

        Loss = Criterion(Output, label)

        print(f"Loss for batch {i}:{Loss}")
        Overall_loss += Loss * n_samples
        Total_samples += n_samples
        # print(Output.shape, label.shape)
        label = label.to(device)
        Output=Output.cpu().numpy()

        print(label.shape,Output.shape)
        extent = [0, 10, 0, 10]
        fig, ax = plt.subplots()
        start = data[0, 0, :, :].clone().cpu().numpy()
        end=data[0, 1, :, :].clone().cpu().numpy()
        obstacle = data[0, 2, :, :].clone().cpu().numpy()
        ax.imshow(obstacle.T, origin='lower', extent=extent, cmap='binary')
        ax.imshow(start.T, origin='lower', extent=extent, cmap='Greens', alpha=0.4)
        ax.imshow(end.T, origin='lower', extent=extent, cmap='Reds', alpha=0.4)
        # label=label.cpu()
        ax.plot(*Output[0].T, color='k', marker='o')
        plt.show()
        print(f'label:{label}')
        print(f'predicted:{Output}')



    print(f"Final Loss:{Overall_loss/Total_samples}")
